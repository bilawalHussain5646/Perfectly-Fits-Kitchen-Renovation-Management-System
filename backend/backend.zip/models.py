from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

from sqlalchemy.dialects.mysql import LONGBLOB

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_super_admin = db.Column(db.Boolean, default=False, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'is_super_admin': self.is_super_admin
        }

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    contact_number = db.Column(db.String(20), nullable=False)
    invoice_price = db.Column(db.Float, nullable=False)
    invoice_image = db.Column(db.String(500), nullable=True)
    invoice_image_data = db.Column(LONGBLOB, nullable=True)
    is_giveaway_eligible = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'contact_number': self.contact_number,
            'invoice_price': self.invoice_price,
            'invoice_image': self.invoice_image,
            'is_giveaway_eligible': self.is_giveaway_eligible,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class GiveawayWinner(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=True)
    winner_name = db.Column(db.String(100), nullable=False)
    winner_email = db.Column(db.String(120), nullable=False)
    winner_contact = db.Column(db.String(20), nullable=False)
    invoice_price = db.Column(db.Float, nullable=False)
    drawn_at = db.Column(db.DateTime, default=datetime.utcnow)

    invoice = db.relationship('Invoice', backref='giveaway_wins', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'winner_name': self.winner_name,
            'winner_email': self.winner_email,
            'winner_contact': self.winner_contact,
            'invoice_price': self.invoice_price,
            'drawn_at': self.drawn_at.isoformat() if self.drawn_at else None
        }
